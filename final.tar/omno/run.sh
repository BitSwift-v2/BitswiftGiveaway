#java -classpath lib/json-simple-1.1.1.jar:./classes concept.omno.Main
java -jar omno.jar