package concept.omno;

import concept.platform.ArdorApi;
import concept.platform.EconomicCluster;
import concept.platform.Transaction;
import concept.utility.FileUtility;
import concept.utility.JsonFunction;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.*;

public class State {
    final static int saveRotateMaxIndex = 20;
    final static int saveHeightCheckpointInterval = 360;
    int versionFromDefinition = 0;

    final private ApplicationContext applicationContext;
    boolean useLowSecurityRandom = true;

    int[] supportedDepositChainTokens = {4}; // Bitswift contest

    final int versionMinimum = 0;
    final int version = 0;

    PickByMessage pickByMessage;
    public EconomicCluster economicCluster;

    StateCache stateCache;

    public JSONObject toJSONObject() {
        JSONObject jsonObject = new JSONObject();

        if (stateCache != null && stateCache.economicCluster.isEqual(economicCluster)) {
            return stateCache.state;
        }

        JsonFunction.put(jsonObject, "version", version);

        JsonFunction.put(jsonObject, "economicCluster", economicCluster.toJSONObject());

        if (pickByMessage != null) {
            JsonFunction.put(jsonObject, "pickByMessage", pickByMessage.toJSONObject());
        }

        stateCache = new StateCache(jsonObject, economicCluster);

        return  jsonObject;
    }

    public void define(JSONObject jsonObject) {

        if (jsonObject == null) {
            return;
        }

        versionFromDefinition = JsonFunction.getInt(jsonObject, "version", 0);

        if (versionFromDefinition > version) {
            applicationContext.logErrorMessage("ERROR : definition (" + versionFromDefinition + ") is from a future version. This application (" + version + ") may be out-of-date.");
        }

        if (versionFromDefinition < versionMinimum) {
            applicationContext.logErrorMessage("ERROR : definition (" + versionFromDefinition + ") is from an unsupported older version. This application's minimum (" + versionMinimum + ")");
        }

        economicCluster = new EconomicCluster(JsonFunction.getJSONObject(jsonObject, "economicCluster", null));

        pickByMessage = new PickByMessage(applicationContext, JsonFunction.getJSONObject(jsonObject, "pickByMessage", null));
    }

    State (ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
        economicCluster = new EconomicCluster(0, 0, 0);

        pickByMessage = new PickByMessage(applicationContext, null);
    }

    State(ApplicationContext applicationContext, JSONObject jsonObject) {
        this(applicationContext);
        define(jsonObject);
    }

    State(ApplicationContext applicationContext, EconomicCluster economicCluster) {
        this(applicationContext);
        this.economicCluster = economicCluster.clone();
    }

    public static class StateCache {
        EconomicCluster economicCluster;
        JSONObject state;

        StateCache(JSONObject jsonObject, EconomicCluster economicCluster) {

            if (economicCluster != null) {
                this.economicCluster = economicCluster.clone();
            }

            this.state = jsonObject;
        }

        public boolean isValid(ArdorApi ardorApi) {
            return (economicCluster.isValid(ardorApi) && state != null);
        }
    }

    public void nextBlock() {
        EconomicCluster economicClusterNext = new EconomicCluster(applicationContext.ardorApi, economicCluster.getHeight() + 1);

        if (!economicClusterNext.isValid(applicationContext.ardorApi)) {
            applicationContext.logInfoMessage("nextBlock not valid : " + economicClusterNext.getHeight() + " : " + economicCluster.getHeight());
            return;
        }

        List<Transaction> listTransactionAll = sortTransactionList(getBlockExecutedTransactionsReceived(economicClusterNext.getHeight()));

        applyIncomingTransactionEffects(listTransactionAll);

        economicCluster = economicClusterNext;
    }


    public boolean isValid() {
        return (economicCluster != null && economicCluster.isValid(applicationContext.ardorApi) && versionFromDefinition <= version && versionFromDefinition >= versionMinimum);
    }

    public static boolean createFileHash(String pathString) {

        byte[] hash = FileUtility.getHash(pathString, "SHA-256");

        if (hash == null || hash.length == 0) {
            return false;
        }

        return FileUtility.writeFile(pathString + ".hash", hash);
    }

    public static boolean verifyFileHash(String pathString) {
        return FileUtility.verifyHash(pathString, FileUtility.readFile(pathString + ".hash"), "SHA-256");
    }

    public static Path getStatePathRotationCreate(Path rootPath) {
        Path result = Paths.get(rootPath.toString() + "/rotate/");

        try {
            Files.createDirectories(result);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return result;
    }

    public static Path getStateFullPathRotation(String name, Path rootPath, String stringId, int index) {
        return Paths.get(getStatePathRotationCreate(rootPath) + "/" + name + "." + stringId + "." + index + ".state");
    }

    public static Path getStateFullPathAtHeight(String name, Path rootPath, EconomicCluster economicCluster) {
        return Paths.get(rootPath.toString() + "/block/" + name + "." + economicCluster.getHeight() + "." + Long.toUnsignedString(economicCluster.getBlockId()) + ".state");
    }

    public static Path getStateFullPathAtHeight(String name, Path rootPath, int height, ArdorApi ardorApi) {
        EconomicCluster economicCluster = new EconomicCluster(ardorApi, height);
        return getStateFullPathAtHeight(name, rootPath, economicCluster);
    }

    public boolean saveState(String fullPath) {
        FileOutputStream fileOutputStream;

        try {
            JSONObject jsonObject = new JSONObject();
            fileOutputStream = new FileOutputStream(fullPath, false);
            ObjectOutputStream objectOutputStream;
            objectOutputStream = new ObjectOutputStream(fileOutputStream);

            applicationContext.signJSONObject(jsonObject, "state", applicationContext.state.toJSONObject());
            objectOutputStream.writeObject(jsonObject);

            objectOutputStream.close();
            fileOutputStream.close();
        } catch (Exception e) {
            applicationContext.logErrorMessage("error : saveState : " + e);
            return false;
        }

        createFileHash(fullPath);

        return true;
    }

    private void saveRotate(String name, Path rootPath, String stringId) {

        for (int i = saveRotateMaxIndex; i > 0; i--) {
            File fileNew = new File(getStateFullPathRotation(name, rootPath, stringId, i - 1).toString());
            File fileOld = new File(getStateFullPathRotation(name, rootPath, stringId, i).toString());

            fileOld.delete();
            fileNew.renameTo(fileOld);

            fileNew = new File(getStateFullPathRotation(name, rootPath, stringId, i - 1) + ".hash");
            fileOld = new File(getStateFullPathRotation(name, rootPath, stringId, i) + ".hash");

            fileOld.delete();
            fileNew.renameTo(fileOld);
        }
    }

    public boolean saveState(String name, Path rootPath) {

        int height = economicCluster.getHeight();

        Path path;

        if (height % saveHeightCheckpointInterval == 0) {
            saveRotate(name, rootPath, "far");
            path = getStateFullPathRotation(name, rootPath, "far", 0);
        } else {
            saveRotate(name, rootPath, "near");
            path = getStateFullPathRotation(name, rootPath, "near", 0);
        }

        saveState(path.toString());

        return true;
    }

    public static State loadState(ApplicationContext applicationContext, String fullPath) {

        if (applicationContext == null || fullPath == null) {
            return null;
        }

        if (!Files.exists(Paths.get(fullPath))) {
            return null;
        }

        if (!verifyFileHash(fullPath)) {
            applicationContext.logInfoMessage("WARNING : state hash verification fail for : " + fullPath);
            return null;
        }

        State result = null;

        try {

            FileInputStream fileInputStream = new FileInputStream(fullPath);
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);

            JSONObject jsonObject = (JSONObject) objectInputStream.readObject();
            JSONObject jsonObjectState = JsonFunction.getJSONObject(jsonObject, "state", null);

            State state = new State(applicationContext, jsonObjectState);

            if (state.isValid() && state.economicCluster.getHeight() >= applicationContext.heightStart) {
                result = state;
            }

        } catch (Exception e) {
            applicationContext.logErrorMessage(e.toString());
        }

        return result;
    }

    public static State loadLastValidState(ApplicationContext applicationContext, String name, Path rootPath) {
        State state = null;

        int index = 0;

        while(state == null && index <= saveRotateMaxIndex) {
            Path path = getStateFullPathRotation(name, rootPath, "near", index++);
            state = loadState(applicationContext, path.toString());
        }

        index = 0;

        while(state == null && index <= saveRotateMaxIndex) {
            Path path = getStateFullPathRotation(name, rootPath, "far", index++);
            state = loadState(applicationContext, path.toString());
        }

        if (applicationContext.reloadAndRescan) {
            return null;
        }

        return state;
    }

    public Random getCombinedRandom(long value, EconomicCluster economicClusterOverride) {
        Random random;

        try {
            random = SecureRandom.getInstance("SHA1PRNG");
        } catch (NoSuchAlgorithmException e) {
            applicationContext.logErrorMessage(e.toString());
            throw new IllegalArgumentException(e);
        }

        MessageDigest digest;

        try {
            digest = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            applicationContext.logErrorMessage(e.toString());
            throw new IllegalArgumentException(e);
        }

        // NOTE this can be mixed with a secret to prevent the block generator manipulating the results
        // and with regular publishing of the block's seed to allow verification of the results
        // With option "useLowSecurityRandom" the verifier can follow the results in-sync and this is convenient for initial release.

        if (!useLowSecurityRandom) {
            if (applicationContext.secretForRandom == null) {
                applicationContext.logErrorMessage("secretForRandom must be configured if useLowSecurityRandom is false");
                throw new NullPointerException();
            }

            digest.update(applicationContext.secretForRandom);
        }

        EconomicCluster economicClusterForSeed = economicCluster;

        if (economicClusterOverride != null) {
            economicClusterForSeed = economicClusterOverride;
        }

        digest.update(ByteBuffer.allocate(Long.BYTES).putLong(value).array());
        digest.update(ByteBuffer.allocate(Long.BYTES).putLong(economicClusterForSeed.getBlockId()).array());
        long seed = ByteBuffer.wrap(digest.digest(), 0, 8).getLong();
        random.setSeed(seed);

        return random;
    }

    private List<Transaction> getBlockExecutedTransactionsReceived(int height, int chain) {
        List<Transaction> listTransaction = new ArrayList<>();

        JSONObject response;

        try {
            response = applicationContext.ardorApi.getExecutedTransactions(applicationContext.adminPasswordString, chain, height, applicationContext.contractAccountId, 0);
        } catch (IOException e) {
            applicationContext.logErrorMessage(e.toString());
            return listTransaction;
        }

        JSONArray transactionsJSONArray = JsonFunction.getJSONArray(response, "transactions", null);

        if (transactionsJSONArray == null || transactionsJSONArray.size() == 0) {
            return listTransaction;
        }

        for (Object o : transactionsJSONArray) {
            JSONObject transactionObject = (JSONObject) o;

            Transaction transaction = new Transaction(transactionObject);

            listTransaction.add(transaction);
        }

        return listTransaction;
    }

    private List<Transaction> getBlockExecutedTransactionsReceived(int height) {
        List<Transaction> listTransaction = new ArrayList<>();

        if (supportedDepositChainTokens == null || supportedDepositChainTokens.length == 0) {
            return listTransaction;
        }

        for (int i = 0; i < supportedDepositChainTokens.length; i++) {
            listTransaction.addAll(getBlockExecutedTransactionsReceived(height, supportedDepositChainTokens[i]));
        }

        return listTransaction;
    }

    private List<Transaction> sortTransactionList(List<Transaction> listTransaction) {

        if (listTransaction == null || listTransaction.size() == 0) {
            return null;
        }

        SortedMap<String, Transaction> sortedMap = new TreeMap<>();

        try {

            MessageDigest digestBlockId;
            digestBlockId = MessageDigest.getInstance("SHA-256");
            digestBlockId.update(ByteBuffer.allocate(Long.BYTES).putLong(economicCluster.getBlockId()).array());

            for (Transaction transaction : listTransaction) {
                MessageDigest digestFullHash = (MessageDigest) digestBlockId.clone();
                sortedMap.put(JsonFunction.hexStringFromBytes(digestFullHash.digest(transaction.fullHash)), transaction);
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return new ArrayList<>(sortedMap.values());
    }

    private List<Transaction> getTransactionsUser(List<Transaction> listTransaction) {
        List<Transaction> result = new ArrayList<>();

        if (listTransaction == null) {
            return result;
        }

        for (Transaction transaction : listTransaction) {
            if (transaction.recipient != transaction.sender && transaction.recipient == applicationContext.contractAccountId) {
                result.add(transaction);
            }
        }

        return result;
    }

    private List<Transaction> applyIncomingTransactionEffects(List<Transaction> listTransaction) {
        List<Transaction> listTransactionFiltered = new ArrayList<>();

        if (listTransaction == null) {
            return listTransactionFiltered;
        }

        for (Transaction transaction : listTransaction) {
            if (transaction.sender == applicationContext.contractAccountId) {
                continue;
            }

            if (transaction.message == null) {
                continue;
            }

            if (!transaction.message.equals(applicationContext.messageForPick)) {
                continue;
            }

            applicationContext.state.pickByMessage.merge(transaction.sender, 1);

            long count = applicationContext.state.pickByMessage.getAccount(transaction.sender);

            if (count == 1) {
                applicationContext.logDebugMessage("new entry for : " + applicationContext.ardorApi.getAccountRSAbbreviated(transaction.sender));
            } else {
                applicationContext.logDebugMessage("extra message : " + applicationContext.ardorApi.getAccountRSAbbreviated(transaction.sender) + " : " + count);
            }

            listTransactionFiltered.add(transaction);
        }

        return listTransactionFiltered;
    }

    public JSONObject apiProcessRequestPlatform(JSONObject jsonObject) {

        if (jsonObject == null) {
            return toJSONObject();
        }

        JSONObject result = new JSONObject();

        EconomicCluster economicCluster = new EconomicCluster(JsonFunction.getJSONObject(jsonObject, "economicCluster", null));

        if (this.economicCluster.isEqual(economicCluster)) {
            JsonFunction.put(result, "isEqual", true);
            return result;
        }

        return toJSONObject();
    }
}
