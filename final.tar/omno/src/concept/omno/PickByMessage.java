package concept.omno;

import concept.utility.JsonFunction;
import org.json.simple.JSONObject;

import java.util.*;

public class PickByMessage {

    final ApplicationContext applicationContext;

    HashMap<Long, Long> accounts = new HashMap<>();

    public JSONObject toJSONObject() {
        JSONObject jsonObject = new JSONObject();

        if (accounts.size() > 0) {
            JsonFunction.put(jsonObject, "account", JsonFunction.jsonObjectStringUnsignedLongPairsFromMap(accounts, false));
        }

        return  jsonObject;
    }

    public void define(JSONObject jsonObject) {

        if (jsonObject == null) {
            return;
        }

        accounts = JsonFunction.getHashMapLongLongFromUnsignedStringKeyValuePairs(jsonObject, "account", accounts);
    }

    PickByMessage(ApplicationContext applicationContext, JSONObject jsonObject) {
        this.applicationContext = applicationContext;
        define(jsonObject);
    }

    public void merge(long accountId, long count) {

        if (accountId == 0) {
            return;
        }

        if (accounts.size() > 0 && accounts.containsKey(accountId)) {
            count += accounts.get(accountId);
        }

        accounts.put(accountId, count);
    }

    public long getIdOfHighestCount() {

        if (accounts.size() == 0) {
            return 0;
        }

        long count = 0;
        long account = 0;

        for (Long id : accounts.keySet()) {
            long countNew = accounts.get(id);

            if (countNew > count) {
                count = countNew;
                account = id;
            }
        }

        return account;
    }

    public long getAccount(long accountId) {

        if (accounts.size() == 0 || !accounts.containsKey(accountId)) {
            return 0;
        }

        return accounts.get(accountId);
    }

    public long getAccountCount() {
        return accounts.size();
    }

    public long getAccountCumulative() {

        if (accounts.size() == 0) {
            return 0;
        }

        long result = 0;

        for (Long value : accounts.values()) {
            result += value;
        }

        return result;
    }

    public LinkedHashMap<Long, Long> createCumulativeMap() {

        if (accounts.size() == 0) {
            return null;
        }

        LinkedHashMap<Long, Long> result = new LinkedHashMap<>();

        SortedSet<Long> sortedSet = new TreeSet<>(accounts.keySet());

        long cumulative = 0;

        for (Long id : sortedSet) {
            cumulative += accounts.get(id);
            result.put(id, cumulative);
        }

        return result;
    }

    public long pickAccount() {

        if (accounts.size() == 0) {
            return 0;
        }

        LinkedHashMap<Long, Long> cumulativeMap = createCumulativeMap();

        if (cumulativeMap.size() == 0) {
            return 0;
        }

        Random random = applicationContext.state.getCombinedRandom(0, null);

        long cumulative = getAccountCumulative();

        double randomDouble = random.nextDouble();
        long randomForPick = (long) (cumulative * randomDouble);

        long result = 0;

        for (long id : cumulativeMap.keySet()) {

            if (cumulativeMap.get(id) > randomForPick) {
                result = id;
                break;
            }
        }

        return result;
    }
}
