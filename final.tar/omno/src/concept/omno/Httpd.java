package concept.omno;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import concept.utility.JsonFunction;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class Httpd implements Runnable {
    final ApplicationContext applicationContext;

    String hostname;
    int port;

    boolean quit = false;

    Httpd(ApplicationContext applicationContext, String hostname, int port) {
        this.applicationContext = applicationContext;
        this.hostname = hostname;
        this.port = port;
    }

    public void stop() {
        quit = true;
    }

    public void run() {

        HttpServer server;

        try {
            server = HttpServer.create(new InetSocketAddress(hostname, port), 0);
        } catch (IOException e) {
            synchronized (applicationContext) {
                applicationContext.logErrorMessage(e.toString());
                applicationContext.logErrorMessage("httpd failed to start");
            }
            return;
        }

        ThreadPoolExecutor threadPoolExecutor = (ThreadPoolExecutor) Executors.newFixedThreadPool(10);

        server.createContext("/api", new HttpHandlerLocal());
        server.setExecutor(threadPoolExecutor);
        server.start();

        synchronized (applicationContext) {
            applicationContext.logInfoMessage("REST API server started : " + hostname + ":" + port + "/api");
            applicationContext.isHttpdRunning = true;
        }

        while(!quit) {
            try {
                TimeUnit.MILLISECONDS.sleep(100);
            } catch (InterruptedException ignored) { }
        }

        synchronized (applicationContext) {
            applicationContext.isHttpdRunning = false;
        }

        server.stop(0);
    }

    private class HttpHandlerLocal implements HttpHandler {

        @Override
        public void handle(HttpExchange httpExchange) throws IOException {
            JSONObject requestParameter = new JSONObject();

            switch (httpExchange.getRequestMethod()) {
                default: {
                    break;
                }

                case "POST": {
//                    requestParameter = processPostRequest(httpExchange);
                    break;
                }

                case "GET": {
                    requestParameter = processGetRequest(httpExchange);
                    break;
                }

            }

            respond(httpExchange, requestParameter);
        }

        private JSONObject processGetRequest(HttpExchange httpExchange) {
            JSONObject response = new JSONObject();

            String requestString = null;

            try {
                String encoded = httpExchange.getRequestURI().toString();

                if (encoded == null || encoded.length() > 1024) {
                    return response;
                }

                requestString = URLDecoder.decode(encoded, "UTF-8");
            } catch (Exception e) {
                applicationContext.logErrorMessage(e.toString());
            }

            if (requestString == null || requestString.length() > 512) {
                return response;
            }

            int index = 0;

            while(index < requestString.length() && requestString.charAt(index) != '?') {
                index++;
            }

            index++;

            if ((index + 2) >= requestString.length()) {
                return response;
            }

            String subString = requestString.substring(index);

            JSONParser jsonParser = new JSONParser();

            try {
                response = (JSONObject) jsonParser.parse(subString);
            } catch (Exception e) {
                return response;
            }

            return response;
        }

        private void respond(HttpExchange httpExchange, JSONObject requestParameter)  throws  IOException {

            JSONObject responseJson = processRequest(requestParameter);

            String responseString = responseJson.toJSONString();

            OutputStream outputStream = httpExchange.getResponseBody();
            httpExchange.sendResponseHeaders(200, responseString.length());
            outputStream.write(responseString.getBytes());
            outputStream.flush();
            outputStream.close();
        }

        private JSONObject processRequest(JSONObject jsonObject) {
            JSONObject response = new JSONObject();

            synchronized (applicationContext) {
                if (!applicationContext.isConfigured) {
                    JsonFunction.put(response, "error", "application not yet configured");
                    return response;
                }

                String apiPassword = JsonFunction.getString(jsonObject, "password", "");

                if (apiPassword == null || !apiPassword.equals(applicationContext.apiPassword)) {
                    JsonFunction.put(response, "error", "incorrect API password attempt");
                    return response;
                }

                String service = JsonFunction.getString(jsonObject, "service", null);

                if (service == null) {
                    JsonFunction.put(response, "error", "service not specified");
                    return response;
                }

                String request = JsonFunction.getString(jsonObject, "request", null);

                JSONObject parameter = JsonFunction.getJSONObject(jsonObject, "parameter", null);

                if (request == null) {
                    JsonFunction.put(response, "error", "request not specified");
                    return response;
                }

                switch (service) {
                    default: {
                        JsonFunction.put(response, "error", "service not found : " + service);
                        return response;
                    }

                    case "platform": {
                        switch (request) {
                            default: {
                                JsonFunction.put(response, "error", "request not found : " + request);
                                return response;
                            }

                            case "state": {
                                JSONObject stateObject = applicationContext.state.apiProcessRequestPlatform(parameter);

                                if (stateObject != null && ! stateObject.containsKey("error")) {
                                    applicationContext.signJSONObject(response, "state", stateObject);
                                } else {
                                    response = stateObject;
                                }

                                break;
                            }
                        }

                        break;
                    }
                }
            }

            return response;
        }
    }
}
