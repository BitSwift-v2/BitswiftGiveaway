while true
do

sh ./run.sh
echo "restarting after delay ..."
sleep 2

done